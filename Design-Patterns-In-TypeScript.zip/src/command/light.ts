// The Light. The Receiver

export default class Light {
    turnOn(): void {
        // A set of instructions to run
        console.log('Light turned ON')
    }

    turnOff(): void {
        // A set of instructions to run
        console.log('Light turned OFF')
    }
}
