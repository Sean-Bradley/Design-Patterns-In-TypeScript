export default interface ISwitchCommand {
    execute(commandName: string): void
}