export default interface ICommand {
    execute(): void
}