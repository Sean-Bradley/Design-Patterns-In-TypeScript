// A Game Interface

export default interface IGame {
    addWinner(position: number, name: string): void
}
