// The Shape Abstraction Interface

export default interface IShape {
    draw(): void
}