// The Shape Implementor Interface

export default interface IShapeImplementor {
    drawImplementation(): void
}