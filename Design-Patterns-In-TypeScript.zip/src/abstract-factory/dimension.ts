export type dimension = {
    height: number
    width: number
    depth: number
}